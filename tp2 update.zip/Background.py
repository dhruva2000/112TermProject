from Jetpack_Joyride import *
from Obstacles import *
from Coins import *
from BarryMotion import *
from cmu_112_graphics import *